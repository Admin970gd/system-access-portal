import os
import sys
import json
import base64
import urllib.request
import urllib.error

REPO = "Shivaram9977/system-access-portal"
BRANCH = "main"

def upload_file(token, file_path, repo_path):
    url = f"https://api.github.com/repos/{REPO}/contents/{repo_path}"
    with open(file_path, "rb") as f:
        content = base64.b64encode(f.read()).decode("utf-8")
    
    # Check if file exists to get SHA
    sha = None
    req = urllib.request.Request(url, headers={
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Antigravity-Deployer"
    })
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode())
            sha = data.get("sha")
    except urllib.error.HTTPError as e:
        if e.code != 404:
            print(f"Error checking {repo_path}: {e}")
            return False
            
    payload = {
        "message": f"Deploy {repo_path}",
        "content": content,
        "branch": BRANCH
    }
    if sha:
        payload["sha"] = sha
        
    data_bytes = json.dumps(payload).encode("utf-8")
    put_req = urllib.request.Request(url, data=data_bytes, headers={
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Antigravity-Deployer"
    }, method="PUT")
    
    try:
        with urllib.request.urlopen(put_req) as resp:
            print(f"Successfully uploaded {repo_path}")
            return True
    except urllib.error.HTTPError as e:
        print(f"Failed to upload {repo_path}: {e.read().decode()}")
        return False

if __name__ == "__main__":
    token = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("GITHUB_TOKEN")
    if not token:
        print("Usage: python upload_to_github.py <GITHUB_PERSONAL_ACCESS_TOKEN>")
        sys.exit(1)
        
    base = os.path.dirname(os.path.abspath(__file__))
    files_to_upload = [
        "license_server.py",
        "render.yaml",
        "Procfile",
        "requirements.txt",
        "README.md",
        ".gitignore"
    ]
    for fn in files_to_upload:
        fp = os.path.join(base, fn)
        if os.path.exists(fp):
            upload_file(token, fp, fn)
